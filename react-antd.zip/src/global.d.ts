

declare interface AnyObject {
  [key: string]: any;
}