const Index = () => {
  return <div>1</div>;
};

export default Index;
