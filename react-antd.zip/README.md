# Notice

This project created by `Vite`, used [`Vite 4`](https://vitejs.dev/), [`React 18.2`](https://reactjs.org/), [`antd 5.5`](https://ant.design/)

## install
```
npm i
npm run dev
```